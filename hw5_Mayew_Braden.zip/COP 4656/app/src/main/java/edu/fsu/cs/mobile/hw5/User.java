//****************************************************************//
// Braden Mayew                                  	              //
// COP 4656 									     	   	      //
// Zach Yannes											          //
// Homework 5                                   	              //
// ------------------------- User.java -------------------------- //
//****************************************************************//
package edu.fsu.cs.mobile.hw5;

import android.os.Parcel;
import android.os.Parcelable;

public class User implements Parcelable {
    String email;
    String password;
    String name;
    String courseCode;
    String role;

    public User() {
        // constructor
    }

    public User(String email, String password, String name, String courseCode, String role) {
        this.email = email;
        this.password = password;
        this.name = name;
        this.courseCode = courseCode;
        this.role = role;
    }

    // ---- Accessors ---- //
    public String getEmail() {
        return email;
    }
    public String getPassword() {
        return password;
    }
    public String getName() {
        return name;
    }
    public String getCourseCode() {
        return courseCode;
    }
    public String getRole() {
        return role;
    }

    // ---- Mutators ---- //
    public void setEmail(String email) { this.email = email; }
    public void setPassword(String password) { this.password = password; }
    public void setName(String name) { this.name = name; }
    public void setCourseCode(String courseCode) { this.courseCode = courseCode; }
    public void setRole(String role) { this.role = role; }

    @Override
    public int describeContents() {
        return 0;
    }

    protected User(Parcel in) {
        email = in.readString();
        password = in.readString();
        name = in.readString();
        courseCode = in.readString();
        role = in.readString();
    }

    public static final Creator<User> CREATOR = new Creator<User>() {
        @Override
        public User createFromParcel(Parcel in) {
            return new User(in);
        }

        @Override
        public User[] newArray(int size) {
            return new User[size];
        }
    };

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(email);
        dest.writeString(password);
        dest.writeString(name);
        dest.writeString(courseCode);
        dest.writeString(role);
    }
}

