package edu.fsu.cs.mobile.hw5;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import edu.fsu.cs.mobile.hw5.contentprovider.UserContract;

// ---- Same form actions and UI as Hmwk II ---- //
/* Modify login operation to use database instead of hardcoded list */

public class LoginFragment extends Fragment {
    Button register_btn;
    Button login_btn;
    EditText emailEntry;
    EditText passwordEntry;

    public LoginFragment() {

    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_login, container, false);

        // ---- LoginButton onClickListener ---- //
        login_btn = (Button) root.findViewById(R.id.goToHomeActivityFromLogin);
        login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emailEntry = getActivity().findViewById(R.id.verifyEmail);
                passwordEntry = getActivity().findViewById(R.id.verifyPassword);

                String em = emailEntry.getText().toString();
                String pass = passwordEntry.getText().toString();
                Log.d("Login", "String" + Login(em, pass));
                if (Login(em, pass) == 1) {
                    Toast.makeText(getContext(), "Successful Login", Toast.LENGTH_SHORT).show();

                    // --- Open HomeActivity ---- //
                    UserContract.DatabaseHelper dbHelper = new UserContract.DatabaseHelper(getContext());
                    SQLiteDatabase db = dbHelper.getWritableDatabase();
                    //db.delete("users", null, null);

                    /* query row number and build the content URI from that row ID */
                    Cursor adapterCursor = db.rawQuery("SELECT * FROM users WHERE email = ? AND password = ?", new String[] {emailEntry.getText().toString(), passwordEntry.getText().toString()});
                    if (adapterCursor != null && adapterCursor.moveToFirst()){
                        final String loginID_Token = adapterCursor.getString(adapterCursor.getColumnIndex("_id"));
                        final Uri loginURI = Uri.parse(UserContract.CONTENT_URI + "/" + loginID_Token);
                        Log.d("Cursor", "ID: " + loginID_Token);
                        adapterCursor.close();

                        if (loginURI != null) {
                            //Intent intent = new Intent(Intent.ACTION_VIEW, newUri);
                            Intent intent = new Intent(getActivity(), HomeActivity.class);
                            intent.putExtra("Uri2", loginURI);
                            startActivity(intent);
                        }
                    }
                } else {
                    Toast.makeText(getContext(), "Unsuccessful Login", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // ---- RegisterButton onClickListener ---- //
        register_btn = (Button) root.findViewById(R.id.goToRegisterFragment);
        register_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // --- Open RegisterFragment ---- //
                RegisterFragment register_fragment = new RegisterFragment();
                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                FragmentTransaction ft = fragmentManager.beginTransaction();
                ft.replace(R.id.fragment_container, register_fragment);
                ft.addToBackStack(null);
                ft.commit();
            }
        });

        return root;
    }

    /* If integer number is 1 then we can say that the user name and password is match other wise we can say login failed. */
    public int Login(String email,String password)
    {
        UserContract.DatabaseHelper dbHelper = new UserContract.DatabaseHelper(getActivity());
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        String[] selectionArgs = new String[]{ email, password};
        try
        {
            int i = 0;
            Cursor c = null;
            c = db.rawQuery("SELECT * FROM users where email=? and password=?", selectionArgs);
            Log.d("Select", c.toString());
            c.moveToFirst();
            i = c.getCount();
            c.close();
            return i;
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return 0;
    }
}
