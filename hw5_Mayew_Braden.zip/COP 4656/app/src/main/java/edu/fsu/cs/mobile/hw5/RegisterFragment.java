package edu.fsu.cs.mobile.hw5;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import edu.fsu.cs.mobile.hw5.contentprovider.UserContract;

import static edu.fsu.cs.mobile.hw5.contentprovider.UserContract.*;
import static edu.fsu.cs.mobile.hw5.contentprovider.UserContract.UserEntry.CLASS_NAME;
import static edu.fsu.cs.mobile.hw5.contentprovider.UserContract.UserEntry.EMAIL;
import static edu.fsu.cs.mobile.hw5.contentprovider.UserContract.UserEntry.LAST_LOGIN;
import static edu.fsu.cs.mobile.hw5.contentprovider.UserContract.UserEntry.NAME;
import static edu.fsu.cs.mobile.hw5.contentprovider.UserContract.UserEntry.PASSWORD;
import static edu.fsu.cs.mobile.hw5.contentprovider.UserContract.UserEntry.ROLE;
import static edu.fsu.cs.mobile.hw5.contentprovider.UserContract.UserEntry.TIMESTAMP;

public class RegisterFragment extends Fragment {
    static EditText email;
    EditText password;
    EditText confirmPassword;
    EditText enterName;
    TextView classPlaceholder;
    Spinner classDropDown;
    RadioGroup roleSelection;
    RadioButton student;
    RadioButton instructor;
    CheckBox agreementCheck;
    Button reset_btn;
    Button register_btn;
    DatabaseHelper mDataBaseHelper;

    public RegisterFragment() {

    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_register, container, false);
        // ----- Email Field ---- //
        email = (EditText) root.findViewById(R.id.email);

        // ---- Password Fields ---- //
        password = (EditText) root.findViewById(R.id.password);
        confirmPassword = (EditText) root.findViewById(R.id.confirmPassword);
        enterName = (EditText) root.findViewById(R.id.enterName);

        // ---- Choose class drop-down menu ---- //
        classPlaceholder = (TextView) root.findViewById(R.id.classPlaceholder);
        classDropDown = (Spinner) root.findViewById(R.id.classDrop_Down);
        // Create and ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getActivity(), R.array.classes, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        classDropDown.setAdapter(adapter);

        // ---- Choose Role ---- //
        roleSelection = (RadioGroup) root.findViewById(R.id.question1);
        student = (RadioButton) root.findViewById(R.id.radio0);
        instructor = (RadioButton) root.findViewById(R.id.radio1);
        student.setChecked(false);
        instructor.setChecked(false);

        // ---- Agree to terms ---- //
        agreementCheck = (CheckBox) root.findViewById(R.id.checkBox);

        // ---- Reset button event handling ---- //
        reset_btn = (Button) root.findViewById(R.id.button_reset);
        reset_btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                email.setText("");
                email.setError(null);
                password.setText("");
                password.setError(null);
                confirmPassword.setText("");
                confirmPassword.setError(null);
                enterName.setText("");
                enterName.setError(null);
                classDropDown.setSelection(0);
                classPlaceholder.setError(null);
                student.setChecked(false);
                student.setError(null);
                instructor.setChecked(false);
                instructor.setError(null);
                agreementCheck.setChecked(false);
                agreementCheck.setError(null);
                register_btn.setError(null);
                register_btn.setBackgroundColor(Color.rgb(119,125,167));
            }
        });

        // ---- Register button event handling ---- //
        register_btn = (Button) root.findViewById(R.id.button_submit);
        register_btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // if all of the data is valid, then store user info with SharedPreferences
                // Save data
                if (saveInfo(v)) {
                    User user = new User();
                    user.setEmail(email.getText().toString());
                    user.setPassword(password.getText().toString());
                    user.setName(enterName.getText().toString());
                    user.setCourseCode(classDropDown.getSelectedItem().toString());
                    if (student.isChecked()) {
                        user.setRole("Student");
                    } else {
                        user.setRole("Teacher");
                    }

                    // ---- ContentValues put here & passed to onInsert method ---- //
                    ContentValues contentValues = new ContentValues();
                    contentValues.put(EMAIL, user.getEmail());
                    contentValues.put(PASSWORD, user.getPassword());
                    contentValues.put(NAME, user.getName());
                    contentValues.put(CLASS_NAME, user.getCourseCode());
                    contentValues.put(ROLE, user.getRole());

                    Date date = Calendar.getInstance().getTime();
                    DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss", Locale.US);
                    String current = dateFormat.format(date);
                    Log.d("LoginTime", current);
                    contentValues.put(LAST_LOGIN, current);

                    /* onInsert called */
                    onInsert(contentValues);
                }
            }
        });
        return root;
    }

    public Boolean saveInfo(View view) {
        int flag = -1; // flag value switch
        if (email.getText().toString().equals("") || password.getText().toString().equals("") || confirmPassword.getText().toString().equals("") || (classDropDown.getSelectedItem().toString().equals("Choose your class")) ||
                (!student.isChecked() && !instructor.isChecked()) || !agreementCheck.isChecked()) {
            Toast toast = Toast.makeText(getActivity(), "All fields must be completed", Toast.LENGTH_LONG);
            toast.setGravity(Gravity.TOP | Gravity.LEFT, 20, 20);
            toast.show();
            email.setError("All fields must be filled out");
            password.setError("All fields must be filled out");
            confirmPassword.setError("All fields must be filled out");
            enterName.setError("All fields must be filled out");
            classPlaceholder.setError("All fields must be filled out");
            instructor.setError("All fields must be filled out");
            agreementCheck.setError("All fields must be filled out");
            return false;
        }


        // ---- Handling email == one of the admin emails ---- //
        String[] admins_Email_StringArray = getResources().getStringArray(R.array.admins);
        for (int i = 0; i < 3; i++) {
            if (email.getText().toString().equals(admins_Email_StringArray[i])) {
                email.setError("Admin Emails are Invalid");
                flag = 0;
            }
        }

        // ---- Handling Password Fields ---- //
        if (!password.getText().toString().equals(confirmPassword.getText().toString())) {
            confirmPassword.setError("Password confirmation does not match");
            flag = 0;
        }

        // ---- Handling Name Field in conjunction with "Students must have names" ---- //
        if (enterName.getText().toString().equals("")) { // if the name is blank, then the user cannot be a student
            if (student.isChecked()) {
                Toast.makeText(getActivity(), "Checking student requires the name field to be filled out", Toast.LENGTH_LONG).show();
                instructor.setError("");
                flag = 0;
            }
        }

        // ---- Agree to terms ---- //
        if (!agreementCheck.isChecked()) {
            Toast.makeText(getActivity(), "Must agree to the terms in order to register", Toast.LENGTH_LONG).show();
            agreementCheck.setError("");
            flag = 0;
        }

        if (flag == 0) {

            return false;
        } else {
            /* Put User in SQLite database */
            Toast.makeText(getActivity(), "Successfully Registered User " + enterName.getText().toString(), Toast.LENGTH_LONG).show();
            return true;
        }
    }

    public void onInsert (ContentValues values) {
        final Uri newUri = getActivity().getContentResolver().insert(UserContract.CONTENT_URI, values);
        if (newUri != null) {
            Intent intent = new Intent(getActivity(), HomeActivity.class);
            intent.putExtra("Uri", newUri);
            startActivity(intent);
        }
    }
}
