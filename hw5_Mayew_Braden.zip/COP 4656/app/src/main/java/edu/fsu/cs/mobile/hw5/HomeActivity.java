package edu.fsu.cs.mobile.hw5;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.method.PasswordTransformationMethod;
import android.text.method.TransformationMethod;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import javax.xml.datatype.Duration;

import edu.fsu.cs.mobile.hw5.contentprovider.UserContract;

import static edu.fsu.cs.mobile.hw5.contentprovider.UserContract.UserEntry.LAST_LOGIN;

public class HomeActivity extends AppCompatActivity {
    Intent intent2;
    Uri uri2;

    TextView textRole;
    TextView textEmail;
    EditText textPassword;
    Button btnPassword;
    TextView textName;
    TextView textClass;
    TextView textTimeStamp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Intent intent = getIntent();
        Uri uri = intent.getParcelableExtra("Uri");
        //Log.d("Uri*", "From Register" + uri.toString());

        // ---- Using intent2 twice ---- //
        /* I declared intent2 and uri2 in the public section because when I try to get intent2 here
         * and get intent2 in the OnOptions Menu Java does a sad face */
        intent2 = getIntent();
        uri2 = intent2.getParcelableExtra("Uri2");
        //Log.d("Uri**", "From Login" + uri2.toString());

        if (uri != null) {
            setupUI(uri);
        } else {
            // ---- Login User ---- //
            /* Update current timestamp */

            /* DOES NOT work */
            UserContract.DatabaseHelper dbHelper = new UserContract.DatabaseHelper(getApplicationContext());
            SQLiteDatabase db2 = dbHelper.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            Date date = Calendar.getInstance().getTime();
            DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss", Locale.US);
            String current = dateFormat.format(date);
            Log.d("LoginTime", current);
            contentValues.put(LAST_LOGIN, current);
            db2.update("users", contentValues, "last_login = ?", new String[] {current});
            int updateInt = db2.update("users", contentValues, "last_login = ?", new String[] {current});
            String updateString = Integer.toString(updateInt);
            Log.d("onUpdate", updateString);
            /* END OF Broken Code */

            setupUI(uri2);
        }


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_home_activity, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.options:
                Toast.makeText(this, "Logging out...", Toast.LENGTH_SHORT).show();
                finish();
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                return true;
            case R.id.options2:
                Toast.makeText(this, "Account Successfully Deleted", Toast.LENGTH_SHORT).show();
                UserContract.DatabaseHelper dbHelper = new UserContract.DatabaseHelper(getApplicationContext());
                SQLiteDatabase db = dbHelper.getWritableDatabase();

                // ---- Getting the rowID from the uri Intent from LoginFragment ---- //
                Intent deleteIntent = getIntent();
                Uri uri = deleteIntent.getParcelableExtra("Uri2");
                String strUri = uri.toString();
                char rowID = strUri.charAt(strUri.length() - 1);
                String rowIDstr = Character.toString(rowID);

                // ---- Find User and Delete ---- //
                db.delete("users", "_id = ?", new String[] { String.valueOf(rowIDstr) });

                Intent intent2 = new Intent(this, MainActivity.class);
                startActivity(intent2);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void setupUI(Uri uri) {
        Cursor cursor = getContentResolver().query(uri,
                null, null, null, null);

        if (cursor == null) {
            return;
        }

        textRole = (TextView) findViewById(R.id.role);
        textEmail = (TextView) findViewById(R.id.emailDisplay);
        textPassword = (EditText) findViewById(R.id.passwordRow);
        btnPassword = (Button) findViewById(R.id.showPassword);
        textName = (TextView) findViewById(R.id.nameDisplay);
        textClass = (TextView) findViewById(R.id.classDisplay);
        textTimeStamp = (TextView) findViewById(R.id.timeStampDisplay);

        if (cursor.getCount() > 0) {
            cursor.moveToNext();

            // Get owner String from Cursor
            String Role = cursor.getString(cursor.getColumnIndex(UserContract.UserEntry.ROLE));
            String Email = cursor.getString(cursor.getColumnIndex(UserContract.UserEntry.EMAIL));
            String Name = cursor.getString(cursor.getColumnIndex(UserContract.UserEntry.NAME));
            String Pass = cursor.getString(cursor.getColumnIndex(UserContract.UserEntry.PASSWORD));
            String Class = cursor.getString(cursor.getColumnIndex(UserContract.UserEntry.CLASS_NAME));
            String TimeStamp = cursor.getString(cursor.getColumnIndex(UserContract.UserEntry.LAST_LOGIN));


            textRole.setText(Role);
            textEmail.setText(Email);
            textName.setText(Name);
            textPassword.setText(Pass);
            textClass.setText(Class);
            textTimeStamp.setText(TimeStamp);
        }

        btnPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textPassword.setTransformationMethod(null);
            }
        });

        // ---- Retrieve the cursor ---- //
        UserContract.DatabaseHelper dbHelper = new UserContract.DatabaseHelper(getApplicationContext());
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        // db.delete("users", null, null);

        /* Retrieve all users for table except the current user */
        Cursor adapterCursor = db.rawQuery("SELECT * FROM users WHERE email != ?", new String[] {textEmail.getText().toString()});
        // Log.d("dbCursor", adapterCursor.toString());

        // ---- Attach the adapter to ListView ---- //
        ListView listView = (ListView) findViewById(R.id.lvData);
        UserCursorAdapter userCursorAdapter = new UserCursorAdapter(this, adapterCursor);
        listView.setAdapter(userCursorAdapter);
        userCursorAdapter.changeCursor(adapterCursor);
    }
}

