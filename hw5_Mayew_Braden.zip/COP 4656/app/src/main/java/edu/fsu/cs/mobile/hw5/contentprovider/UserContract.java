package edu.fsu.cs.mobile.hw5.contentprovider;

import android.content.ContentResolver;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import android.provider.BaseColumns;
import android.util.Log;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import static edu.fsu.cs.mobile.hw5.contentprovider.UserContract.UserEntry.EMAIL;
import static edu.fsu.cs.mobile.hw5.contentprovider.UserContract.UserEntry.NAME;
import static edu.fsu.cs.mobile.hw5.contentprovider.UserContract.UserEntry.PASSWORD;
import static java.security.AccessController.getContext;

public class UserContract {
    private static final String TAG = UserContract.class.getCanonicalName();
    public final static String DBNAME = "users.db";
    public final static int DBVERSION = 1;

    public static final int URI_USERS = 1;
    public static final int URI_USER_ID = 2;

    public static final String AUTHORITY = "edu.fsu.cs.mobile.hw5.contentprovider.provider";

    // BaseColumns provides _ID and _COLUMN columns to table
    public class UserEntry implements BaseColumns {
        // Define the Table Name
        public static final String TABLE_NAME = "users";
        public static final String TIMESTAMP = "timestamp";

        public static final String KEY_ROWID = "_id";
        public static final String EMAIL = "email";
        public static final String PASSWORD = "password";
        public static final String NAME = "name";
        public static final String ROLE = "role";
        public static final String CLASS_NAME = "class_name";
        public static final String LAST_LOGIN = "last_login";
    }

    public static final Uri CONTENT_URI = Uri.parse("content://" + AUTHORITY + "/" + UserEntry.TABLE_NAME);
    public static final String CONTENT_TYPE = ContentResolver.CURSOR_DIR_BASE_TYPE + "/" + AUTHORITY + "/" + UserEntry.TABLE_NAME;
    public static final String CONTENT_ITEM_TYPE = ContentResolver.CURSOR_ITEM_BASE_TYPE + "/" + AUTHORITY + "/" + UserEntry.TABLE_NAME;

    // Create table statement
    public static final String SQL_CREATE_USER_TABLE = "CREATE TABLE " + UserEntry.TABLE_NAME + " (" +
            UserEntry.KEY_ROWID + " integer PRIMARY KEY autoincrement, " +
            UserEntry.EMAIL + " TEXT," +
            UserEntry.PASSWORD + " TEXT," +
            UserEntry.NAME + " TEXT," +
            UserEntry.ROLE + " TEXT," +
            UserEntry.CLASS_NAME + " TEXT," +
            UserEntry.LAST_LOGIN +  " TEXT" + ");";

    public static class DatabaseHelper extends SQLiteOpenHelper {
        // ---- Helper class for creating/updating db and providing db handle to contentprovider ---- //
        public DatabaseHelper(Context context) {
            super(context, DBNAME, null, DBVERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
                    Log.i(TAG, "Creating: " + SQL_CREATE_USER_TABLE);
            db.execSQL(SQL_CREATE_USER_TABLE);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL(String.format(Locale.US,
                    "DROP TABLE IF EXISTS %s", UserEntry.TABLE_NAME));
            onCreate(db);
        }
    }
}


