package edu.fsu.cs.mobile.hw5;

import android.content.ContentValues;
import android.database.Cursor;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import edu.fsu.cs.mobile.hw5.contentprovider.UserContract;

// ---- Contains LoginFragment and RegisterFragment ---- //
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ---- Open LoginFragment onStart of MainActivity ---- //
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction trans = manager.beginTransaction();
        LoginFragment loginFragment = new LoginFragment();
        trans.add(R.id.fragment_container, loginFragment);
        trans.addToBackStack(null);
        trans.commit();
    }

}
